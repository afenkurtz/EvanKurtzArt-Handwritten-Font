This font is based on my own handwriting, with a focus on stylistic accuracy. 
It is not meant for copy where legibility is critical, and is really only intended for use as an ancillary element, as it will likely need adjusting.

The font is licensed under the open license framework of the SIL Open Font License. See the license file in the download directory for specific details. This front is 100% free and open source. 

For more information, visit the github repository: https://github.com/afenkurtz/EvanKurtzArt-Handwritten-Font
See the version history file in the download directory for changelogs.